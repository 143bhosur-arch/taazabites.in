

import React, { useState } from 'react';

export const CorporateBooking: React.FC = () => {
    const [formData, setFormData] = useState({
        corpName: '',
        corpContact: '',
        numEmployees: '10',
        mealType: 'Daily Lunch/Dinner',
        startDate: '',
    });
    const [errors, setErrors] = useState({
        corpName: '',
        corpContact: '',
        numEmployees: '',
        startDate: '',
    });
    const [isImageLoaded, setIsImageLoaded] = useState(false);
    const imageUrl = 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?ixlib=rb-4.0.3&fm=webp';

    const validate = () => {
        const newErrors = { corpName: '', corpContact: '', numEmployees: '', startDate: '' };
        let isValid = true;
        
        if (!formData.corpName.trim()) {
            newErrors.corpName = 'Company name is required.';
            isValid = false;
        }
        if (!formData.corpContact.trim()) {
            newErrors.corpContact = 'Contact person/number is required.';
            isValid = false;
        }
        if (parseInt(formData.numEmployees, 10) < 10) {
            newErrors.numEmployees = 'Minimum of 10 employees required.';
            isValid = false;
        }
        if (!formData.startDate) {
            newErrors.startDate = 'Please select a start date.';
            isValid = false;
        } else if (new Date(formData.startDate) < new Date(new Date().setHours(0,0,0,0))) {
            newErrors.startDate = 'Start date cannot be in the past.';
            isValid = false;
        }

        setErrors(newErrors);
        return isValid;
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({...prev, [name]: value}));
        if (errors[name as keyof typeof errors]) {
            setErrors(prev => ({...prev, [name]: ''}));
        }
    };

    const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (!validate()) return;

        const rawMessage = [
            '*CORPORATE ENQUIRY - Taazabites*',
            '---',
            `*Company:* ${formData.corpName}`,
            `*Contact:* ${formData.corpContact}`,
            `*Employees:* ${formData.numEmployees}`,
            `*Meal Type:* ${formData.mealType}`,
            `*Start Date:* ${formData.startDate}`,
            '---',
            'Please contact me to discuss a corporate meal partnership!'
        ].join('\n');

        const encodedMessage = encodeURIComponent(rawMessage);
        
        window.open(`https://wa.me/917975771457?text=${encodedMessage}`, '_blank');
    };

  return (
    <section id="corporate-booking" className="py-16 sm:py-20 md:py-24 text-white relative overflow-hidden bg-zinc-900">
      <div className="absolute inset-0 image-container">
        <img
          src={`${imageUrl}&w=1280&q=60`}
          srcSet={`${imageUrl}&w=640&q=50 640w, ${imageUrl}&w=1280&q=60 1280w, ${imageUrl}&w=1920&q=70 1920w`}
          sizes="100vw"
          alt="A professional team collaborating in a modern office, representing Taazabites corporate wellness plans."
          loading="lazy"
          decoding="async"
          className={`w-full h-full object-cover ${isImageLoaded ? 'is-loaded' : ''}`}
          onLoad={() => setIsImageLoaded(true)}
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900/90 via-zinc-900/80 to-black/95"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12 animate-on-scroll" data-animation="slide-fade-in-up">
          <h2 className="text-3xl md:text-4xl font-bold font-iowan text-white inline-block relative pb-2">
            Corporate Meal Plans in Bengaluru
            <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-20 h-1 bg-[var(--accent)]"></span>
          </h2>
           <p className="max-w-2xl mx-auto mt-4 text-white/80">Fuel your team's success and elevate productivity with healthy, delicious meals delivered to your Bengaluru office.</p>
        </div>

        <div className="max-w-5xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column: Info */}
          <div className="animate-on-scroll" data-animation="slide-in-left" data-stagger-delay="0.2s">
            <h3 className="text-2xl md:text-3xl font-bold font-iowan text-white mb-4">A Partnership in Wellness & Productivity</h3>
            <p className="text-white/80 mb-6 text-lg">Invest in your team's well-being with our tailored corporate meal solutions. We handle the food, so you can focus on what you do best.</p>
            <ul className="space-y-4 text-white/90">
              {['Flexible Daily/Weekly Delivery', 'Dedicated Account Manager', 'Custom Budgeting & Menu Cycles', 'Catering for Meetings & Events'].map((item, i) => (
                <li key={i} className="flex items-center gap-3 bg-white/5 p-3 rounded-lg border-l-4 border-[var(--primary)]">
                  <i className="fas fa-check-circle text-[var(--primary)]"></i> {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Right Column: Form */}
          <div className="bg-black/20 backdrop-blur-lg border border-white/20 rounded-2xl p-6 md:p-8 animate-on-scroll" data-animation="slide-in-right" data-stagger-delay="0.2s">
            <h4 className="text-2xl font-bold text-center text-white mb-6 font-iowan">Get a Custom Quote</h4>
            <form onSubmit={handleFormSubmit} className="space-y-4 form-glow" noValidate>
              <div>
                <label htmlFor="corpName" className="block text-sm font-semibold text-white/80 mb-1">Company Name</label>
                <input type="text" id="corpName" name="corpName" value={formData.corpName} onChange={handleChange} className={`w-full px-4 py-2 bg-white/10 border  rounded-lg outline-none transition-shadow ${errors.corpName ? 'border-red-500' : 'border-white/20'}`} placeholder="Your Company Name" />
                {errors.corpName && <p className="text-red-400 text-xs mt-1">{errors.corpName}</p>}
              </div>
               <div>
                <label htmlFor="corpContact" className="block text-sm font-semibold text-white/80 mb-1">Your Name / Contact</label>
                <input type="text" id="corpContact" name="corpContact" value={formData.corpContact} onChange={handleChange} className={`w-full px-4 py-2 bg-white/10 border rounded-lg outline-none transition-shadow ${errors.corpContact ? 'border-red-500' : 'border-white/20'}`} placeholder="Name and Phone Number" />
                {errors.corpContact && <p className="text-red-400 text-xs mt-1">{errors.corpContact}</p>}
              </div>
               <div>
                <label htmlFor="numEmployees" className="block text-sm font-semibold text-white/80 mb-1">Number of Employees</label>
                <input type="number" id="numEmployees" name="numEmployees" value={formData.numEmployees} onChange={handleChange} min="10" className={`w-full px-4 py-2 bg-white/10 border rounded-lg outline-none transition-shadow ${errors.numEmployees ? 'border-red-500' : 'border-white/20'}`} placeholder="e.g., 50" />
                {errors.numEmployees && <p className="text-red-400 text-xs mt-1">{errors.numEmployees}</p>}
              </div>
              <div>
                <label htmlFor="mealType" className="block text-sm font-semibold text-white/80 mb-1">Preferred Meal Type</label>
                <select id="mealType" name="mealType" value={formData.mealType} onChange={handleChange} className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg outline-none transition-shadow">
                  <option className="bg-zinc-800">Daily Lunch/Dinner</option>
                  <option className="bg-zinc-800">Weekly Subscription</option>
                  <option className="bg-zinc-800">Catering for Events</option>
                  <option className="bg-zinc-800">Custom Plan</option>
                </select>
              </div>
              <div>
                <label htmlFor="startDate" className="block text-sm font-semibold text-white/80 mb-1">Estimated Start Date</label>
                <input type="date" id="startDate" name="startDate" value={formData.startDate} onChange={handleChange} className={`w-full px-4 py-2 bg-white/10 border rounded-lg outline-none transition-shadow ${errors.startDate ? 'border-red-500' : 'border-white/20'}`} />
                {errors.startDate && <p className="text-red-400 text-xs mt-1">{errors.startDate}</p>}
              </div>
              <button type="submit" className="w-full bg-[var(--accent-secondary)] text-white font-bold py-3 px-6 rounded-lg hover:bg-[#F84D15] shadow-lg shadow-[var(--accent-secondary)]/20 hover:scale-105 transition-all duration-300 flex items-center justify-center gap-2 ripple-effect">
                <i className="fab fa-whatsapp"></i> Send Enquiry via WhatsApp
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};